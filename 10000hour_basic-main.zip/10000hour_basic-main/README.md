# 10000hour_basic
초급자를 위한 1만시간의 법칙 베이직 강의입니다. 이 강의는 초급자를 위해 만든 것이라 풀 버전이 아닙니다.

## 대상
* HTML과 CSS에 대한 기본 개념을 이제 막 익히신 분

## 사용 방법
오른쪽 상단에 Code를 클릭하신 후 다운로드 받으셔서 basic 폴더를 에디터로 열고 유튜브 영상을 참고하여 코딩해보세요. 최종 코드는 final에 있습니다.

* 디자인 링크: https://www.figma.com/design/YIoHn24LhFrCBEedo96rx6/1만-시간의-법칙?node-id=0-1&t=vpDa4YqQtZj9i22Z-0

## 풀버전
* https://paullabkorea.github.io/10000hour/ 에서 풀 버전 홈페이지 확인이 가능합니다.
* https://github.com/paullabkorea/10000hour repo에서 풀 버전 코드를 확인하실 수 있습니다.
* 해당 제작 과정의 풀 버전은 무료강의로 오픈이 되어 있습니다. https://inf.run/j2JD 에서 확인이 가능합니다.
